define([
    "dojo/_base/declare",
    "esriMaps/extensions/behaviors/_MapBehavior"
], function(declare, _MapBehavior) {

    // Create a custom behavior by inheriting MapBehavior class
    return declare(_MapBehavior, {

        // Since this behavior is a _MapBehavior, set the eventName to 'click' event.
        // The _MapBehavior wires up the click event to the Map and execute function when the event fires.
        eventName: "click",

        execute: function() {
            // execute will be called when someone clicks on the map
            alert("This is not actually shown on the page or logged");
        }
    });

});
