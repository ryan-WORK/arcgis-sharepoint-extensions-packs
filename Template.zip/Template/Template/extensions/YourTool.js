define([
    "dojo/_base/declare",
    "esriMaps/extensions/tools/_Tool",
    "xstyle/css!../css/example.css"
], function(declare, _Tool) {

    // Create a custom tool by inheriting _Tool class
    return declare(_Tool, {

        execute: function() { // Function that will be called when the tool is clicked in the app
            this.app.showMessage("This is an example of what is displayed");
            console.log("Some Data about the map");
        }
    });
});
